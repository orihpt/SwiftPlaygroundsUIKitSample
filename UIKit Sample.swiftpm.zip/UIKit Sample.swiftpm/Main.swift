import UIKit

// This is the main View Controller.
class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "This is UIKit!"
        
        view.addSubview(l)
        view.centerXAnchor.constraint(equalTo: l.centerXAnchor).isActive = true
        view.centerYAnchor.constraint(equalTo: l.centerYAnchor).isActive = true
    }
}

